import json
import boto3
import os

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['TASKS_TABLE'])

def lambda_handler(event, context):
    try:
        task_id = event['pathParameters']['taskId']
        body = json.loads(event['body'])
        new_status = body.get('status')

        if new_status not in ['pending', 'in-progress', 'completed', 'overdue']:
            return { 'statusCode': 400, 'body': json.dumps({ 'error': 'Invalid status' }) }

        table.update_item(
            Key={'taskId': task_id},
            UpdateExpression="SET #s = :status",
            ExpressionAttributeNames={"#s": "status"},
            ExpressionAttributeValues={":status": new_status}
        )

        return { 'statusCode': 200, 'body': json.dumps({ 'message': 'Task status updated' }) }

    except Exception as e:
        return { 'statusCode': 500, 'body': json.dumps({ 'error': str(e) }) }
